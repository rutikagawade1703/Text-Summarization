# Data-Summarization

Deployed:- https://arshdeep.pythonanywhere.com/

"app.py" is the code for data summarization. For using this code please clone this repo. as the structuring/documentation is very important. 
